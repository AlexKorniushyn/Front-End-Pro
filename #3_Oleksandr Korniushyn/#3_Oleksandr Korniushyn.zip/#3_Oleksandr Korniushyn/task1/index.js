const operator = getEnterOperator("+, -, *, /");

const numberFirst = getEnterNumber("first");

const numberSecond = getEnterNumber("second");

const result = calc(operator, numberFirst, numberSecond);

showResult(operator, numberFirst, numberSecond, result);

function getEnterOperator(operator) {
  return prompt(`Enter your operator ${operator}`);
}

function getEnterNumber(numberName) {
  return Number(prompt(`Enter your ${numberName} number`));
}

function calc(operator, x, y) {
  let result;

  if (operator === "+") {
    result = x + y;
  } else if (operator === "-") {
    result = x - y;
  } else if (operator === "*") {
    result = x * y;
  } else if (operator === "/") {
    result = x / y;
  }
  return result;
}

function showResult(operator, x, y, result) {
  alert(`Your result: ${x} ${operator} ${y} = ${result}`);
}
