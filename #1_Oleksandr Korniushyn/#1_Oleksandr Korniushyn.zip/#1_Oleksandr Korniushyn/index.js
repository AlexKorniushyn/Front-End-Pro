const yourName = prompt("What's your name?");

alert(`Hello, ${yourName}! How are you?`);
