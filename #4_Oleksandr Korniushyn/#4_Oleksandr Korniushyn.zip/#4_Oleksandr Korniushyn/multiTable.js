for (i = 1; i <= 10; i += 1) {
  for (x = 1; x <= 10; x += 1) {
    numbers = i * x;
    console.log(numbers + ";");
  }
}
